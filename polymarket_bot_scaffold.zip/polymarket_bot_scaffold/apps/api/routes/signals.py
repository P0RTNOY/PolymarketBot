from fastapi import APIRouter
from bot.strategies.eth_direction_15m import ETHDirection15mStrategy
from bot.execution.types import MarketSnapshot

router = APIRouter()

@router.get("/preview")
def preview_signal() -> dict:
    strategy = ETHDirection15mStrategy()
    snapshot = MarketSnapshot.example()
    signal = strategy.evaluate(snapshot)
    return signal.model_dump()
