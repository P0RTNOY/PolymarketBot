from fastapi import APIRouter
from bot.clients.polymarket_public import PolymarketPublicClient

router = APIRouter()

@router.get("")
async def list_markets(limit: int = 20) -> dict:
    client = PolymarketPublicClient()
    markets = await client.list_active_markets(limit=limit)
    return {"items": markets, "count": len(markets)}
