import asyncio
from bot.execution.paper_trader import PaperTrader
from bot.execution.types import MarketSnapshot
from bot.strategies.eth_direction_15m import ETHDirection15mStrategy

async def main() -> None:
    strategy = ETHDirection15mStrategy()
    trader = PaperTrader()
    while True:
        snapshot = MarketSnapshot.example()
        signal = strategy.evaluate(snapshot)
        order = trader.maybe_place_order(signal, snapshot)
        if order:
            print("[paper_trader]", order.model_dump_json(indent=2))
        else:
            print("[paper_trader] no order placed")
        await asyncio.sleep(20)

if __name__ == "__main__":
    asyncio.run(main())
