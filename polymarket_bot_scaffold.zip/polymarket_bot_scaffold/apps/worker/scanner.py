import asyncio
from bot.clients.polymarket_public import PolymarketPublicClient

async def main() -> None:
    client = PolymarketPublicClient()
    while True:
        markets = await client.list_active_markets(limit=5)
        print(f"[scanner] fetched {len(markets)} markets")
        await asyncio.sleep(10)

if __name__ == "__main__":
    asyncio.run(main())
