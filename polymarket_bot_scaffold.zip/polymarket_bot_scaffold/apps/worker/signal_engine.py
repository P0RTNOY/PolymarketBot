import asyncio
from bot.execution.types import MarketSnapshot
from bot.strategies.eth_direction_15m import ETHDirection15mStrategy

async def main() -> None:
    strategy = ETHDirection15mStrategy()
    while True:
        snapshot = MarketSnapshot.example()
        signal = strategy.evaluate(snapshot)
        print("[signal_engine]", signal.model_dump_json(indent=2))
        await asyncio.sleep(15)

if __name__ == "__main__":
    asyncio.run(main())
