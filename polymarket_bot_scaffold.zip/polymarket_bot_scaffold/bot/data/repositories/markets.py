from sqlalchemy import select
from bot.data.models import Market
from bot.data.session import SessionLocal

class MarketRepository:
    def list_markets(self) -> list[Market]:
        with SessionLocal() as session:
            return list(session.scalars(select(Market)))

    def upsert_many(self, markets: list[dict]) -> None:
        with SessionLocal() as session:
            for item in markets:
                row = session.get(Market, item["id"])
                if row is None:
                    row = Market(
                        id=item["id"],
                        condition_id=item.get("condition_id"),
                        question=item.get("question", ""),
                        category=item.get("category"),
                        active=item.get("active", True),
                        closed=item.get("closed", False),
                        raw_json=item,
                    )
                    session.add(row)
                else:
                    row.question = item.get("question", row.question)
                    row.category = item.get("category", row.category)
                    row.active = item.get("active", row.active)
                    row.closed = item.get("closed", row.closed)
                    row.raw_json = item
            session.commit()
