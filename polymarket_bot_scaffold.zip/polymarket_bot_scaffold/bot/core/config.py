from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "dev"
    app_name: str = "polymarket-bot"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    database_url: str = "sqlite+pysqlite:///./polymarket_bot.db"
    redis_url: str = "redis://localhost:6379/0"

    live_trading_enabled: bool = False
    paper_trading_enabled: bool = True
    panic_stop: bool = False

    max_order_usd: float = 10.0
    max_market_exposure_usd: float = 20.0
    max_daily_loss_usd: float = 30.0
    min_edge: float = 0.04
    max_spread: float = 0.02
    min_depth_usd: float = 50.0

    polymarket_api_base: str = "https://example.invalid"
    polymarket_wss_base: str = "wss://example.invalid/ws"
    polymarket_private_key: str = ""
    polymarket_api_key: str = ""
    polymarket_api_secret: str = ""
    polymarket_passphrase: str = ""

@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
