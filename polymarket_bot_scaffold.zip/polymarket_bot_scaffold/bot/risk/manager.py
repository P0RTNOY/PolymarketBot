from bot.core.config import get_settings
from bot.execution.types import TradeSignal, MarketSnapshot

class RiskManager:
    def approve(self, signal: TradeSignal, snapshot: MarketSnapshot) -> tuple[bool, str]:
        s = get_settings()

        if s.panic_stop:
            return False, "panic_stop_enabled"
        if not s.paper_trading_enabled and not s.live_trading_enabled:
            return False, "all_trading_disabled"
        if snapshot.spread > s.max_spread:
            return False, "spread_too_wide"
        if min(snapshot.bid_depth_usd, snapshot.ask_depth_usd) < s.min_depth_usd:
            return False, "insufficient_depth"
        if signal.edge < s.min_edge:
            return False, "edge_below_threshold"
        if signal.suggested_size_usd > s.max_order_usd:
            return False, "size_above_limit"

        return True, "approved"
