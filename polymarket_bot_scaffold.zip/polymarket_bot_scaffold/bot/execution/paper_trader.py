from bot.execution.types import TradeSignal, MarketSnapshot, OrderIntent
from bot.risk.manager import RiskManager

class PaperTrader:
    def __init__(self) -> None:
        self.risk = RiskManager()

    def maybe_place_order(self, signal: TradeSignal, snapshot: MarketSnapshot) -> OrderIntent | None:
        approved, reason = self.risk.approve(signal, snapshot)
        if not approved:
            return None
        return OrderIntent(
            mode="paper",
            market_id=signal.market_id,
            token_id=signal.token_id,
            side=signal.side,
            price=signal.suggested_price,
            size_usd=signal.suggested_size_usd,
        )
