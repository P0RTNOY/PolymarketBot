from __future__ import annotations
import httpx
from bot.core.config import get_settings

class PolymarketPublicClient:
    def __init__(self) -> None:
        self.settings = get_settings()

    async def list_active_markets(self, limit: int = 20) -> list[dict]:
        # Replace this stub with the real public market-data endpoints.
        # Keep it safe for offline development by returning deterministic examples.
        return [
            {
                "id": f"market-{i}",
                "condition_id": f"condition-{i}",
                "question": f"ETH up in 15 minutes? sample market {i}",
                "category": "crypto",
                "active": True,
                "closed": False,
            }
            for i in range(1, limit + 1)
        ]

    async def fetch_book(self, token_id: str) -> dict:
        return {
            "token_id": token_id,
            "best_bid": 0.67,
            "best_ask": 0.69,
            "midpoint": 0.68,
            "spread": 0.02,
            "bid_depth_usd": 250.0,
            "ask_depth_usd": 180.0,
        }
