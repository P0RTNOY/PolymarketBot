from math import exp
from bot.core.config import get_settings
from bot.execution.types import MarketSnapshot, TradeSignal
from bot.strategies.base import Strategy

class ETHDirection15mStrategy(Strategy):
    name = "eth_direction_15m_v1"

    def evaluate(self, snapshot: MarketSnapshot) -> TradeSignal:
        settings = get_settings()
        # Very simple starter model: convert recent return and volatility into a directional probability.
        score = (snapshot.recent_return_1m * 120.0) - (snapshot.realized_vol_15m * 8.0) + 0.35
        model_prob = 1.0 / (1.0 + exp(-score))
        market_prob = snapshot.midpoint
        edge = model_prob - market_prob
        confidence = max(0.05, min(0.95, 0.50 + edge))
        side = "BUY_YES" if edge >= 0 else "BUY_NO"
        suggested_price = snapshot.best_ask if side == "BUY_YES" else max(0.01, 1.0 - snapshot.best_bid)
        suggested_size = settings.max_order_usd if edge >= settings.min_edge else 0.0
        reason = "edge_above_threshold" if suggested_size > 0 else "edge_below_threshold"

        return TradeSignal(
            strategy_name=self.name,
            market_id=snapshot.market_id,
            token_id=snapshot.token_id,
            side=side,
            market_prob=market_prob,
            model_prob=model_prob,
            edge=edge,
            confidence=confidence,
            suggested_price=suggested_price,
            suggested_size_usd=suggested_size,
            reason=reason,
        )
